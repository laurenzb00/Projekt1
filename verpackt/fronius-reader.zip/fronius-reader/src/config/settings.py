API_ENDPOINT = "http://<inverter-ip>/solar_api/v1/"
TIMEOUT = 10  # seconds
RETRY_COUNT = 3

# Add any other configuration settings or constants needed for the application here.